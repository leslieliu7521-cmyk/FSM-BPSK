# FSM v3 完整交付包

请运行 FSM_BPSK_full_system_v3.m，不要误运行original目录内保留的旧程序。
需要MATLAB R2018b+及Signal Processing Toolbox。默认quick，正式模式每条件1000次，须自行明确选择full。

先阅读 FSM_v3_运行说明.md；修改细节和实际验证边界见另外两份中文报告。
当前机器无MATLAB/Octave，未完成原生运行和正式千次实验；Python交叉检查不能替代MATLAB运行。

自检：fsm_options=struct('mode','selftest'); run('FSM_BPSK_full_system_v3.m');
快速：fsm_options=struct('mode','quick'); run('FSM_BPSK_full_system_v3.m');
正式：fsm_options=struct('mode','full'); run('FSM_BPSK_full_system_v3.m');
