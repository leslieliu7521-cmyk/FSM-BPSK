# FSM v4 交付包

在MATLAB中运行FSM_BPSK_full_system_v4.m；先mode=selftest，再mode=diagnostic且diagnosticTrials=1。需要MATLAB R2018b+与Signal Processing Toolbox。默认不运行full。

详细命令、30/100次配对、coverage、full、恢复和读取见FSM_v4_运行说明.md。修改与诊断尺度见FSM_v4_修改说明.md。真实执行记录/未验证项目见FSM_v4_验证报告.md。

这是故障定位版本，完整先验误锁尚未证明已解决。当前环境无MATLAB/Octave，Python122条配对输出不代表MATLAB结果或122次独立统计试验。原v3与原始程序均保留。

Python复核：python v4_validation/validate_v4.py --structural-only；需要NumPy/SciPy。可选语法解析依赖tree-sitter与tree-sitter-matlab，它们不能替代MATLAB语义检查。
