# 固定+700Hz/s正式实验

在MATLAB中进入解压目录，明确启动：

```matlab
fsm_options=struct('mode','full');
run('FSM_BPSK_rate700.m');
```

需要MATLAB R2018b+和Signal Processing Toolbox。建议先按FSM_700Hz每秒实验说明.md执行selftest和quick。主观测100ms，五个Eb/N0，每个含噪条件1000次；接收机仍搜索50--150kHz、+-1000Hz/s，不知道真值700。

完整单文件包含实际频域FSM及所有局部函数。当前无MATLAB原生运行和正式结果，不保证成功率超过90%。原v3/v4保持原样。
