# FSM正式实验包

需要MATLAB R2018b+和Signal Processing Toolbox。先执行v4 selftest，再明确启动正式实验：

```matlab
fsm_options=struct('mode','selftest');
run('FSM_BPSK_full_system_v4.m');
FSM_BPSK_formal_experiment
```

正式入口固定full，每个含噪条件1000次，可能耗时数小时。运行与恢复/结果读取见FSM_正式实验说明.md。结束后调用FSM_BPSK_formal_report('实际输出目录/results.mat')。

当前环境没有MATLAB/Octave，没有正式实验结果，不保证−7dB成功率超过90%。15项源码/配置检查通过；语法解析不是原生运行。原v3/v4未改动，旧Python结果不是正式1000次成绩。保留原频域FSM与全先验搜索。
