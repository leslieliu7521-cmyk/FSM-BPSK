# FSM第一层700Hz/s精简基线

唯一默认入口：

```matlab
run('FSM_BPSK_stage1_700.m')
```

需要MATLAB R2018b+及Signal Processing Toolbox，不需要Parallel Computing Toolbox。新工作区默认3个Eb/N0（-10/-7/-4）、100ms、700Hz/s、每条件50个独立基础试验，150条配对含噪输出。默认不画图/不存FIG或波形。旧stage1_options会保留，重跑时请明确设新结构。

只有第一层：候选生成/去重/精确确认/最佳离散点，无连续优化器调用。原700/v4参考文件仅保留，不要误跑它们。

运行选项、100/1000次、窗口/率对照和恢复见FSM_stage1_运行说明.md；数学定义见FSM_stage1_修改说明.md；实际检查与限制见FSM_stage1_验证报告.md。

当前没有MATLAB原生运行、150次实验成绩或MATLAB总耗时估计。Python检查105项通过，不能当作MATLAB运行或总体成功率保证。
