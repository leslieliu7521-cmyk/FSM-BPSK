# FSM第一层700Hz/s：已恢复原仿真图

```matlab
stage1_options=struct('makePlot',true,'simulationPlots',true);
run('FSM_BPSK_stage1_700.m')
```

默认仍为700Hz/s、100ms、三个Eb/N0、每条件50次，共150条配对输出，只有第一层。恢复9张PNG：链路波形、局部循环谱、统计/分布/逐次估计、轨迹、窗长、候选和一致性分析。数据先保存，逐图失败独立计数，不保存整条高采样率波形。

已有先前第一层results.mat，可只绘图，不重新估计、不覆盖原统计：

```matlab
stage1_options=struct('plotFile','实际结果目录/results.mat');
run('FSM_BPSK_stage1_700.m');
```

需要MATLAB R2018b+及Signal Processing Toolbox。旧指标版保留为FSM_BPSK_stage1_700_metrics.m，可恢复旧检查点。其他v4/原700文件仅为参考，不要误跑。详见三份中文说明。

当前没有MATLAB原生图形/运行验证；118项结构与Python检查不能替代MATLAB。
